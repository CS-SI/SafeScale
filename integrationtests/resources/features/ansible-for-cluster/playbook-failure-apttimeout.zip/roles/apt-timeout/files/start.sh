#!/bin/bash
echo "Configure APT broken proxy"
sudo rm -f /etc/apt/apt.conf.d/_proxy.conf
sudo touch /etc/apt/apt.conf.d/_proxy.conf 
sudo chmod 0777 /etc/apt/apt.conf.d/_proxy.conf
echo "Acquire::http::Proxy \"http://127.0.0.1:8765/\";" > /etc/apt/apt.conf.d/_proxy.conf
echo "Acquire::https::Proxy \"http://127.0.0.1:8765/\";" >> /etc/apt/apt.conf.d/_proxy.conf
echo "Start broken local server"
node /tmp/broken-server/broken-server.js &


