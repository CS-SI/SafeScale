const Net 		= require('net');
var server 		= null;
var sockerId 	= 0;

function RestartServer(){
	if(server==null){
		server = Net.createServer((socket) => {
			sockerId = (sockerId + 1) % 65536;
			socket.socketId = sockerId
			console.log('Client #'+socket.socketId+' incoming');
			socket.on('end', () => {
				console.log('Client #'+socket.socketId+' left');
			});
		});
		server.on('error', (err) => {
			console.error(err);
			if(err.code !== 'EADDRINUSE'){
				if(server!=null){
					server = null;
					process.nextTick(() => {
						RestartServer()
					})
				}
			}
		});
		server.listen(8765, () => {
			console.log('Broken server is now listening port 8765');
		});
	}
}
RestartServer()



