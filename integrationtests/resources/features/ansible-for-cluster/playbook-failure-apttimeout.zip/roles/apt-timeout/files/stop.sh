#!/bin/bash
echo "Stop broken local server"
kill -9 $(ps -ef | grep -m1 broken-server.js | awk '{print $2}')
echo "Remove APT broken proxy configuration"
sudo rm -f /etc/apt/apt.conf.d/_proxy.conf



